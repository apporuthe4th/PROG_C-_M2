namespace PJ3;

class QuizVraagAntwoord()
{
    internal QuizVraag vraag;
    internal bool goed;

}


